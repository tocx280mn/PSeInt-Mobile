8
2 1 1 
* Este ejemplo es simplemente para ver el esqueleto de un programa.
2 2 1 
Por ejemplo, en C++ ver�a la declaraci�n del main y el return 0
2 3 1 
al final.
2 4 1 
* Tambi�n es para ver c�mo se introducen comentarios en el c�digo.
3 6 1 PROCESO SIN_TITULO
1 7

sin_titulo

2 7 1 
por favor, poner una linea de comentarios como esta en el c�digo resultante
7 8 1 ESCRIBIR 'Hola Mundo';
1 1
'Hola Mundo'
4 9 1 FINPROCESO
1 sin_titulo
